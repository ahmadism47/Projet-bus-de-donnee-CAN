/*
 * MadgwickAHRS.c
 *
 *  Created on: 20 oct. 2023
 *      Author: a3achak
 */


