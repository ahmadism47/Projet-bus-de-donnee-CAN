#ifndef IHM_H
#define IHM_H


class IHM
{
public:
    IHM();
};

#endif // IHM_H
