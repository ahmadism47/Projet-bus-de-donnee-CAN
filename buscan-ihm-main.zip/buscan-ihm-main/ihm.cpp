#include "ihm.h"

IHM::IHM()
{

}
